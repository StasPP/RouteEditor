Vampyre Imaging Library
http://imaginglib.sourceforge.net

version 0.26.4 (11th October 2009)

If you are looking for some information open imaging.html or Imaging*.chm or look
at library's homepage.